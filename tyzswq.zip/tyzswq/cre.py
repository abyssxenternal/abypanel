﻿import tkinter as tk
from tkinter import ttk, scrolledtext, filedialog, messagebox
import threading
import time
import os
import json
import random
import re
from datetime import datetime, timedelta
from PIL import Image, ImageTk
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.action_chains import ActionChains
import requests

# ========== CẤU HÌNH ==========
LOGIN_URL = "https://ai-undress.ai/vi/auth/login?returnUrl=%2F"
TIMEOUT = 30
DOCUMENTS_PATH = os.path.expanduser("~/Documents")
ACCOUNTS_FILE = os.path.join(DOCUMENTS_PATH, "accounts.txt")
DOWNLOAD_FOLDER = os.path.join(DOCUMENTS_PATH, "AI_Output")
BLACKLIST_FILE = os.path.join(DOCUMENTS_PATH, "used_accounts.json")
BLACKLIST_HOURS = 24

API_URL = "http://sg4.stacloudnode.me:26666"
API_KEY = "zerxenternal"
HEADERS = {"X-API-Key": API_KEY}

DISCORD_WEBHOOK_URL = "https://discord.com/api/webhooks/1507378921518137505/pwdCxzt-XYJXUbcaMlSU03Z3gaHjjM1QqmBFyY6JS77wen6_UY-gT4AtgUOLZJsiJ0n6"

os.makedirs(DOWNLOAD_FOLDER, exist_ok=True)

DEFAULT_PROMPT = "undress, naked, bigboobs and cum on her"

def quick_delay(min_sec=0.2, max_sec=0.5):
    time.sleep(random.uniform(min_sec, max_sec))

def type_fast(element, text):
    element.click()
    element.clear()
    for char in text:
        element.send_keys(char)
        time.sleep(random.uniform(0.01, 0.03))

def send_image_link_to_discord(image_url, email):
    try:
        caption = f"✅ THÀNH CÔNG\n📧 {email}\n🔗 {image_url}"
        requests.post(DISCORD_WEBHOOK_URL, json={'content': caption}, timeout=10)
        return True
    except:
        return False

def send_file_to_discord(file_path, email):
    try:
        with open(file_path, 'rb') as f:
            caption = f"✅ THÀNH CÔNG\n📧 {email}"
            requests.post(DISCORD_WEBHOOK_URL, data={'content': caption}, files={'file': f}, timeout=30)
        return True
    except:
        return False

def is_valid_email(email):
    if not email:
        return False
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return re.match(pattern, email) is not None

def extract_email_from_line(line):
    line = line.strip()
    if not line:
        return None
    email_pattern = r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}'
    match = re.search(email_pattern, line)
    if match:
        return match.group()
    return None

class AIToolGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("AI Tool v4.0 - Horizontal Layout")
        self.root.geometry("950x700")
        self.root.resizable(True, True)
        self.root.configure(bg='#1e1e2e')

        self.is_running = False
        self.driver = None
        self.image_list = []
        self.processed_images = []
        self.accounts = []
        self.used_accounts = set()
        self.current_mail = None

        self.download_file = tk.BooleanVar(value=True)
        self.get_link = tk.BooleanVar(value=True)
        self.send_tick = tk.BooleanVar(value=True)
        self.use_api_direct = tk.BooleanVar(value=False)

        self.setup_ui()
        self.load_blacklist()
        self.load_accounts_from_file()
        self.update_acc_display()

    # ========== API Functions ==========
    def download_all_mails(self):
        self.add_log("📡 Đang tải tất cả mail...")
        try:
            r = requests.get(f"{API_URL}/api/download/all", headers=HEADERS, timeout=30)
            if r.status_code == 200:
                emails = []
                for line in r.text.splitlines():
                    email = extract_email_from_line(line)
                    if email and is_valid_email(email):
                        emails.append(email)
                
                with open(ACCOUNTS_FILE, 'w', encoding='utf-8') as f:
                    for email in emails:
                        f.write(f"{email}\n")
                self.add_log(f"✅ Đã lưu {len(emails)} email hợp lệ")
                self.load_accounts_from_file()
            else:
                self.add_log(f"⚠️ Lỗi: {r.status_code}")
        except Exception as e:
            self.add_log(f"⚠️ Lỗi: {e}")

    def download_unticked_mails(self):
        self.add_log("📡 Đang tải mail chưa dùng...")
        try:
            r = requests.get(f"{API_URL}/api/download/unticked", headers=HEADERS, timeout=30)
            if r.status_code == 200:
                emails = []
                for line in r.text.splitlines():
                    email = extract_email_from_line(line)
                    if email and is_valid_email(email):
                        emails.append(email)
                
                with open(ACCOUNTS_FILE, 'w', encoding='utf-8') as f:
                    for email in emails:
                        f.write(f"{email}\n")
                self.add_log(f"✅ Đã lưu {len(emails)} email hợp lệ")
                self.load_accounts_from_file()
            else:
                self.add_log(f"⚠️ Lỗi: {r.status_code}")
        except Exception as e:
            self.add_log(f"⚠️ Lỗi: {e}")

    def tick_mail(self, mail):
        if not self.send_tick.get():
            return True
        try:
            r = requests.post(f"{API_URL}/api/mail/tick", headers=HEADERS, json={"mail": mail}, timeout=10)
            if r.status_code == 200:
                self.add_log(f"✅ Đã tick: {mail}")
                return True
            return False
        except:
            return False

    def get_random_mail_api(self):
        try:
            r = requests.get(f"{API_URL}/api/mail/random", headers=HEADERS, timeout=10)
            if r.status_code == 200:
                data = r.json()
                mail = data.get('mail')
                if mail and is_valid_email(mail):
                    return mail, mail
            return None, None
        except:
            return None, None

    # ========== File Functions ==========
    def load_accounts_from_file(self):
        self.accounts = []
        if os.path.exists(ACCOUNTS_FILE):
            with open(ACCOUNTS_FILE, 'r', encoding='utf-8') as f:
                for line in f:
                    line = line.strip()
                    if not line or line.startswith('#'):
                        continue
                    email = extract_email_from_line(line)
                    if email and is_valid_email(email):
                        self.accounts.append((email, email))
            self.add_log(f"📁 Đã tải {len(self.accounts)} tài khoản")
        else:
            self.add_log("⚠️ Chưa có file accounts.txt")

    def load_blacklist(self):
        if os.path.exists(BLACKLIST_FILE):
            with open(BLACKLIST_FILE, 'r', encoding='utf-8') as f:
                data = json.load(f)
                self.used_accounts = set(data.get('blacklist', []))
        else:
            self.used_accounts = set()

    def save_blacklist(self):
        with open(BLACKLIST_FILE, 'w', encoding='utf-8') as f:
            json.dump({'blacklist': list(self.used_accounts)}, f)

    def add_to_blacklist(self, email):
        self.used_accounts.add(email)
        self.save_blacklist()
        self.update_acc_display()

    def get_account_from_file(self):
        available = [e for e, _ in self.accounts if e not in self.used_accounts]
        if not available:
            return None, None
        email = random.choice(available)
        return email, email

    def update_acc_display(self):
        available = len([e for e, _ in self.accounts if e not in self.used_accounts])
        self.acc_status.config(text=f"📊 Tổng: {len(self.accounts)} | Khả dụng: {available}")

    # ========== UI Setup - Horizontal Layout ==========
    def setup_ui(self):
        colors = {
            'bg': '#1e1e2e', 
            'card': '#2a2a3e', 
            'btn_success': '#4ecdc4', 
            'btn_primary': '#667eea', 
            'btn_danger': '#ff6b6b',
            'btn_warning': '#ffe66d',
            'text': '#ffffff',
            'text_sec': '#a0a0b0'
        }
        
        main = tk.Frame(self.root, bg=colors['bg'])
        main.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        # Header
        header = tk.Frame(main, bg=colors['bg'])
        header.pack(fill=tk.X, pady=(0, 10))
        tk.Label(header, text="🤖 AI TOOL v4.0 - HORIZONTAL LAYOUT", font=('Segoe UI', 16, 'bold'), 
                bg=colors['bg'], fg=colors['text']).pack()
        tk.Label(header, text="Tự động tạo ảnh với AI Undress", font=('Segoe UI', 9), 
                bg=colors['bg'], fg=colors['text_sec']).pack()

        # === ROW 1: TÀI KHOẢN + TÙY CHỌN ===
        row1 = tk.Frame(main, bg=colors['bg'])
        row1.pack(fill=tk.X, pady=5)
        
        frame_acc = tk.LabelFrame(row1, text="📧 TÀI KHOẢN", bg=colors['card'], fg=colors['text'], 
                                  font=('Segoe UI', 10, 'bold'), padx=8, pady=5)
        frame_acc.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 5))
        
        btn_frame_acc = tk.Frame(frame_acc, bg=colors['card'])
        btn_frame_acc.pack(fill=tk.X, pady=5)
        
        tk.Button(btn_frame_acc, text="📥 TẤT CẢ", command=self.download_all_mails,
                 bg=colors['btn_primary'], fg='white', font=('Segoe UI', 9, 'bold'),
                 padx=10, pady=4, relief=tk.FLAT, cursor='hand2').pack(side=tk.LEFT, padx=2)
        
        tk.Button(btn_frame_acc, text="📥 CHƯA DÙNG", command=self.download_unticked_mails,
                 bg=colors['btn_success'], fg='white', font=('Segoe UI', 9, 'bold'),
                 padx=10, pady=4, relief=tk.FLAT, cursor='hand2').pack(side=tk.LEFT, padx=2)
        
        tk.Button(btn_frame_acc, text="🔄 TẢI LẠI", command=self.load_accounts_from_file,
                 bg=colors['btn_warning'], fg='#333', font=('Segoe UI', 9, 'bold'),
                 padx=10, pady=4, relief=tk.FLAT, cursor='hand2').pack(side=tk.LEFT, padx=2)
        
        self.acc_status = tk.Label(frame_acc, text="📊 Đang tải...", bg=colors['card'], 
                                   fg=colors['text_sec'], font=('Segoe UI', 8), anchor='w')
        self.acc_status.pack(fill=tk.X, padx=5, pady=2)
        
        frame_opts = tk.LabelFrame(row1, text="⚙️ TÙY CHỌN", bg=colors['card'], fg=colors['text'],
                                   font=('Segoe UI', 10, 'bold'), padx=8, pady=5)
        frame_opts.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True, padx=(5, 0))
        
        tk.Checkbutton(frame_opts, text="🎲 Lấy mail trực tiếp từ API (mỗi lần 1 mail)",
                      variable=self.use_api_direct, bg=colors['card'], fg=colors['text'],
                      selectcolor=colors['card'], font=('Segoe UI', 9)).pack(anchor='w', padx=5, pady=2)
        
        tk.Checkbutton(frame_opts, text="✅ Gửi tick API khi dùng xong (đánh dấu đã sử dụng)",
                      variable=self.send_tick, bg=colors['card'], fg=colors['text'],
                      selectcolor=colors['card'], font=('Segoe UI', 9)).pack(anchor='w', padx=5, pady=2)

        # === ROW 2: PROMPT ===
        frame_prompt = tk.LabelFrame(main, text="✏️ PROMPT", bg=colors['card'], fg=colors['text'],
                                     font=('Segoe UI', 10, 'bold'), padx=8, pady=5)
        frame_prompt.pack(fill=tk.X, pady=5)
        
        self.prompt_text = tk.Text(frame_prompt, height=2, wrap=tk.WORD, font=('Segoe UI', 9),
                                   bg='#3a3a4e', fg=colors['text'], insertbackground='white',
                                   relief=tk.FLAT, padx=5, pady=5)
        self.prompt_text.pack(fill=tk.X, padx=5, pady=5)
        self.prompt_text.insert('1.0', DEFAULT_PROMPT)

        # === ROW 3: DANH SÁCH ẢNH + XUẤT ẢNH ===
        row3 = tk.Frame(main, bg=colors['bg'])
        row3.pack(fill=tk.BOTH, expand=True, pady=5)
        
        frame_images = tk.LabelFrame(row3, text="🖼️ DANH SÁCH ẢNH", bg=colors['card'], fg=colors['text'],
                                     font=('Segoe UI', 10, 'bold'), padx=8, pady=5)
        frame_images.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 5))
        
        self.img_listbox = tk.Listbox(frame_images, height=8, font=('Consolas', 8),
                                      bg='#3a3a4e', fg=colors['text'], selectbackground=colors['btn_primary'])
        self.img_listbox.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        btn_frame_img = tk.Frame(frame_images, bg=colors['card'])
        btn_frame_img.pack(fill=tk.X, padx=5, pady=5)
        
        tk.Button(btn_frame_img, text="➕ THÊM ẢNH", command=self.add_images,
                 bg=colors['btn_success'], fg='white', font=('Segoe UI', 9, 'bold'),
                 padx=12, pady=4, relief=tk.FLAT, cursor='hand2').pack(side=tk.LEFT, padx=2)
        
        tk.Button(btn_frame_img, text="🗑️ XÓA CHỌN", command=self.remove_selected,
                 bg=colors['btn_danger'], fg='white', font=('Segoe UI', 9, 'bold'),
                 padx=12, pady=4, relief=tk.FLAT, cursor='hand2').pack(side=tk.LEFT, padx=2)
        
        tk.Button(btn_frame_img, text="🧹 XÓA HẾT", command=self.clear_all_images,
                 bg=colors['btn_warning'], fg='#333', font=('Segoe UI', 9, 'bold'),
                 padx=12, pady=4, relief=tk.FLAT, cursor='hand2').pack(side=tk.LEFT, padx=2)
        
        frame_output = tk.LabelFrame(row3, text="📥 XUẤT ẢNH", bg=colors['card'], fg=colors['text'],
                                     font=('Segoe UI', 10, 'bold'), padx=8, pady=5)
        frame_output.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True, padx=(5, 0))
        
        tk.Checkbutton(frame_output, text="💾 Tải file ảnh về máy\n   (lưu vào Documents/AI_Output)",
                      variable=self.download_file, bg=colors['card'], fg=colors['text'],
                      selectcolor=colors['card'], font=('Segoe UI', 9), justify=tk.LEFT).pack(anchor='w', padx=5, pady=5)
        
        tk.Checkbutton(frame_output, text="🔗 Gửi link ảnh lên Discord",
                      variable=self.get_link, bg=colors['card'], fg=colors['text'],
                      selectcolor=colors['card'], font=('Segoe UI', 9)).pack(anchor='w', padx=5, pady=5)

        # === ROW 4: TRẠNG THÁI + NÚT ĐIỀU KHIỂN ===
        row4 = tk.Frame(main, bg=colors['bg'])
        row4.pack(fill=tk.X, pady=5)
        
        frame_status = tk.LabelFrame(row4, text="📊 TRẠNG THÁI", bg=colors['card'], fg=colors['text'],
                                     font=('Segoe UI', 10, 'bold'), padx=8, pady=5)
        frame_status.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 5))
        
        self.status_label = tk.Label(frame_status, text="🟢 Sẵn sàng", bg=colors['card'], 
                                     fg=colors['text_sec'], anchor='w', font=('Segoe UI', 9))
        self.status_label.pack(fill=tk.X, padx=5, pady=2)
        
        self.progress_label = tk.Label(frame_status, text="📊 Tiến độ: 0/0", bg=colors['card'],
                                        fg=colors['text_sec'], anchor='w', font=('Segoe UI', 9))
        self.progress_label.pack(fill=tk.X, padx=5, pady=2)
        
        self.acc_label = tk.Label(frame_status, text="📧 Tài khoản: Chưa lấy", bg=colors['card'],
                                   fg=colors['text_sec'], anchor='w', font=('Segoe UI', 9))
        self.acc_label.pack(fill=tk.X, padx=5, pady=2)
        
        self.progress = ttk.Progressbar(frame_status, mode='indeterminate')
        self.progress.pack(fill=tk.X, padx=5, pady=5)
        
        frame_control = tk.LabelFrame(row4, text="🎮 ĐIỀU KHIỂN", bg=colors['card'], fg=colors['text'],
                                      font=('Segoe UI', 10, 'bold'), padx=8, pady=5)
        frame_control.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True, padx=(5, 0))
        
        btn_frame_ctrl = tk.Frame(frame_control, bg=colors['card'])
        btn_frame_ctrl.pack(fill=tk.BOTH, expand=True, pady=10)
        
        self.start_btn = tk.Button(btn_frame_ctrl, text="🚀 BẮT ĐẦU", command=self.start_batch,
                                  bg=colors['btn_success'], fg='white', font=('Segoe UI', 12, 'bold'),
                                  padx=20, pady=12, relief=tk.FLAT, cursor='hand2')
        self.start_btn.pack(side=tk.LEFT, expand=True, fill=tk.BOTH, padx=5)
        
        self.stop_btn = tk.Button(btn_frame_ctrl, text="⏹️ DỪNG KHẨN CẤP", command=self.stop_process,
                                 bg=colors['btn_danger'], fg='white', font=('Segoe UI', 12, 'bold'),
                                 padx=20, pady=12, relief=tk.FLAT, cursor='hand2', state=tk.DISABLED)
        self.stop_btn.pack(side=tk.RIGHT, expand=True, fill=tk.BOTH, padx=5)

        # === ROW 5: LOG ===
        frame_log = tk.LabelFrame(main, text="📋 LOG CHI TIẾT", bg=colors['card'], fg=colors['text'],
                                  font=('Segoe UI', 10, 'bold'), padx=8, pady=5)
        frame_log.pack(fill=tk.BOTH, expand=True, pady=5)
        
        self.log_text = scrolledtext.ScrolledText(frame_log, height=10, wrap=tk.WORD,
                                                   font=('Consolas', 8), bg='#0a0a12', fg='#ccc')
        self.log_text.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        footer = tk.Frame(main, bg=colors['bg'])
        footer.pack(fill=tk.X, pady=(5, 0))
        tk.Label(footer, text=f"📁 Ảnh output lưu tại: {DOWNLOAD_FOLDER}", font=('Segoe UI', 8), 
                bg=colors['bg'], fg='#666').pack()

    # ========== Image Functions ==========
    def add_images(self):
        files = filedialog.askopenfilenames(filetypes=[("Image files", "*.jpg *.jpeg *.png *.webp")])
        for f in files:
            if f not in self.image_list:
                self.image_list.append(f)
                self.img_listbox.insert(tk.END, os.path.basename(f))
        self.add_log(f"📁 Thêm {len(files)} ảnh")
        self.update_progress_label()

    def remove_selected(self):
        selected = self.img_listbox.curselection()
        for idx in reversed(selected):
            self.img_listbox.delete(idx)
            del self.image_list[idx]
        self.add_log(f"🗑️ Xóa {len(selected)} ảnh")
        self.update_progress_label()

    def clear_all_images(self):
        self.image_list.clear()
        self.img_listbox.delete(0, tk.END)
        self.add_log("🧹 Xóa hết ảnh")
        self.update_progress_label()

    def update_progress_label(self):
        total = len(self.processed_images) + len(self.image_list)
        done = len(self.processed_images)
        self.progress_label.config(text=f"📊 Tiến độ: {done}/{total}")

    def add_log(self, msg):
        timestamp = time.strftime('%H:%M:%S')
        self.log_text.insert(tk.END, f"[{timestamp}] {msg}\n")
        self.log_text.see(tk.END)
        self.root.update_idletasks()

    def update_status(self, text):
        self.status_label.config(text=text)

    # ========== Selenium Functions ==========
    def get_result_image_url(self, driver):
        try:
            download_btn = driver.find_element(By.XPATH, "//button[contains(., 'Download')]")
            onclick = download_btn.get_attribute('onclick')
            if onclick:
                urls = re.findall(r'https?://[^\s"\']+\.(jpg|jpeg|png|webp|gif)', onclick, re.IGNORECASE)
                if urls:
                    return urls[0]
            result_img = driver.find_element(By.CSS_SELECTOR, 'img[src*="result"], img[src*="imgproxy"]')
            src = result_img.get_attribute('src')
            if src and src.startswith('http'):
                return src
            return None
        except:
            return None

    def wait_for_result(self, driver, timeout=600):
        start_time = time.time()
        result_url = None
        download_btn = None
        
        self.add_log("⏳ Chờ ảnh được tạo (tối đa 10 phút)...")
        
        while time.time() - start_time < timeout:
            if not self.is_running:
                return None, None
            try:
                btns = driver.find_elements(By.XPATH, "//button[contains(., 'Download')]")
                for btn in btns:
                    if btn.is_displayed() and btn.is_enabled():
                        download_btn = btn
                        elapsed = int(time.time() - start_time)
                        self.add_log(f"✅ Nút Download xuất hiện sau {elapsed}s")
                        break
                if download_btn:
                    break
            except:
                pass
            
            elapsed = int(time.time() - start_time)
            if elapsed > 0 and elapsed % 60 == 0:
                self.add_log(f"⏳ Đã chờ {elapsed//60} phút...")
            time.sleep(2)
        
        if not download_btn:
            self.add_log("❌ Hết thời gian chờ 10 phút")
            return None, None
        
        result_url = self.get_result_image_url(driver)
        if result_url:
            self.add_log(f"🔗 Đã lấy link ảnh")
        
        return download_btn, result_url

    def process_one_image(self, image_path, email, password, prompt, mail=None):
        driver = None
        try:
            self.add_log(f"🚀 {email} - {os.path.basename(image_path)}")
            
            options = webdriver.ChromeOptions()
            options.add_argument('--start-maximized')
            options.add_argument('--disable-gpu')
            options.add_argument('--ignore-certificate-errors')
            options.add_argument('--disable-blink-features=AutomationControlled')
            options.add_experimental_option('excludeSwitches', ['enable-automation'])
            
            prefs = {"download.default_directory": DOWNLOAD_FOLDER, "download.prompt_for_download": False}
            options.add_experimental_option("prefs", prefs)
            
            driver = webdriver.Chrome(options=options)
            self.driver = driver

            driver.get(LOGIN_URL)
            time.sleep(2)
            
            try:
                age_btn = WebDriverWait(driver, 3).until(EC.element_to_be_clickable((By.XPATH, "//button[contains(text(), 'Tôi từ 18')]")))
                age_btn.click()
                time.sleep(0.5)
            except:
                pass
            
            email_input = WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.NAME, "email")))
            pwd_input = driver.find_element(By.NAME, "password")
            
            type_fast(email_input, email)
            quick_delay(0.1, 0.2)
            type_fast(pwd_input, password)
            quick_delay(0.1, 0.2)
            
            login_btn = driver.find_element(By.XPATH, "//button[contains(text(), 'Đăng nhập')]")
            if not login_btn.is_enabled():
                self.add_log("🛡️ Captcha, bỏ qua")
                return False
            
            login_btn.click()
            time.sleep(3)

            file_input = WebDriverWait(driver, 15).until(EC.presence_of_element_located((By.CSS_SELECTOR, 'input[type="file"]')))
            file_input.send_keys(os.path.abspath(image_path))
            time.sleep(3)

            custom = WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.XPATH, "//div[contains(text(), 'Custom')]")))
            driver.execute_script("arguments[0].scrollIntoView({block: 'center'});", custom)
            ActionChains(driver).move_to_element(custom).click().perform()
            time.sleep(1.5)

            textarea = WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.ID, "sex-pose-custom-prompt")))
            textarea.click()
            textarea.clear()
            textarea.send_keys(prompt)
            time.sleep(1)

            create_btn = WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.XPATH, "//button[contains(@class, 'rounded-full') and contains(., 'Tạo')]")))
            create_btn.click()
            self.add_log("✨ Đã click Tạo, đang xử lý...")

            download_btn, image_url = self.wait_for_result(driver, timeout=600)
            
            if not download_btn:
                self.add_log("❌ Không có kết quả sau 10 phút")
                return False
            
            success = False
            
            if image_url:
                send_image_link_to_discord(image_url, email)
                self.add_log("📨 Đã gửi link ảnh lên Discord")
                success = True
            
            if self.download_file.get():
                try:
                    download_btn.click()
                    self.add_log("💾 Đã click Download")
                    time.sleep(5)
                    
                    files = [f for f in os.listdir(DOWNLOAD_FOLDER) if not f.endswith('.crdownload')]
                    if files:
                        latest = max([os.path.join(DOWNLOAD_FOLDER, f) for f in files], key=os.path.getctime)
                        if os.path.getsize(latest) > 0:
                            send_file_to_discord(latest, email)
                            self.add_log(f"📨 Đã gửi file lên Discord")
                            success = True
                except Exception as e:
                    self.add_log(f"⚠️ Lỗi tải file: {e}")
            
            if success:
                if mail and self.send_tick.get():
                    self.tick_mail(mail)
                else:
                    self.add_to_blacklist(email)
                if image_path not in self.processed_images:
                    self.processed_images.append(image_path)
                return True
            return False

        except Exception as e:
            self.add_log(f"⚠️ Lỗi: {str(e)[:60]}")
            return False
        finally:
            if driver:
                driver.quit()
                self.driver = None

    def run_batch(self):
        if not self.image_list:
            self.add_log("❌ Chưa có ảnh")
            self.stop_process()
            return

        prompt = self.prompt_text.get('1.0', tk.END).strip()
        if not prompt:
            prompt = DEFAULT_PROMPT

        total = len(self.image_list)
        self.add_log(f"📊 BẮT ĐẦU: {total} ảnh")
        
        remaining = self.image_list.copy()
        success = 0
        
        while remaining and self.is_running:
            idx = len(self.processed_images) + 1
            img = remaining.pop(0)
            
            self.progress_label.config(text=f"📊 Tiến độ: {idx}/{total}")
            self.add_log(f"📷 ẢNH {idx}/{total}: {os.path.basename(img)}")
            
            if self.use_api_direct.get():
                mail, _ = self.get_random_mail_api()
                if not mail:
                    self.add_log("❌ Hết mail API")
                    break
                email, pwd, mail_id = mail, mail, mail
                self.acc_label.config(text=f"📧 {email} (API)")
            else:
                email, pwd = self.get_account_from_file()
                if not email:
                    self.add_log("❌ Hết tài khoản")
                    break
                mail_id = None
                self.acc_label.config(text=f"📧 {email} (File)")
            
            ok = self.process_one_image(img, email, pwd, prompt, mail_id)
            if ok:
                success += 1
                self.remove_image_from_list(img)
            else:
                if self.is_running:
                    remaining.append(img)
                    self.add_log(f"🔄 Thử lại ảnh này sau")
            
            if remaining and self.is_running:
                wait = random.uniform(3, 6)
                self.add_log(f"⏸️ Nghỉ {wait:.0f}s")
                time.sleep(wait)
        
        self.add_log(f"🎉 KẾT THÚC: Thành công {success}/{total}")
        self.stop_process()

    def remove_image_from_list(self, img_path):
        for i in range(self.img_listbox.size()):
            if self.img_listbox.get(i) == os.path.basename(img_path):
                self.img_listbox.delete(i)
                break
        if img_path in self.image_list:
            self.image_list.remove(img_path)
        self.update_progress_label()

    def start_batch(self):
        if self.is_running:
            return
        if not self.image_list:
            messagebox.showwarning("Thiếu ảnh", "Thêm ảnh trước khi chạy!")
            return
        if not self.use_api_direct.get() and not self.accounts:
            messagebox.showwarning("Thiếu tài khoản", "Tải mail từ API hoặc thêm file accounts.txt!")
            return
        self.is_running = True
        self.start_btn.config(state=tk.DISABLED)
        self.stop_btn.config(state=tk.NORMAL)
        self.progress.start(10)
        self.update_status("🔄 Đang xử lý...")
        self.add_log("🚀 BẮT ĐẦU XỬ LÝ")
        threading.Thread(target=self.run_batch, daemon=True).start()

    def stop_process(self):
        self.is_running = False
        self.progress.stop()
        if self.driver:
            try:
                self.driver.quit()
            except:
                pass
            self.driver = None
        self.start_btn.config(state=tk.NORMAL)
        self.stop_btn.config(state=tk.DISABLED)
        self.update_status("🟢 Đã dừng")
        self.add_log("⏹️ Đã dừng tool")

if __name__ == "__main__":
    root = tk.Tk()
    app = AIToolGUI(root)
    root.mainloop()