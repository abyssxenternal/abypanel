﻿@echo off
title Cai dat thu vien Python

echo Dang cai dat cac thu vien...
python -m pip install --upgrade pip

pip install selenium requests pillow webdriver-manager certifi urllib3 undetected-chromedriver selenium-stealth fake-useragent

echo.
echo Cai dat hoan tat!
pause