﻿import tkinter as tk
from tkinter import ttk, scrolledtext
import threading
import time
import re
import uuid
import requests
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, ElementClickInterceptedException
import warnings
import urllib3
import os
from datetime import datetime
import sys

warnings.filterwarnings('ignore')
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# ========== CẤU HÌNH ==========
DISCORD_WEBHOOK_URL = "https://discord.com/api/webhooks/1431932279017701448/PidYmO6qdMpV_LnXK8svYOL1npKV3CTVrTi2o4Ds_hbW-CIm1aN8d1L3HxBwVzspfeT1"
DOCUMENTS_PATH = os.path.expanduser("~/Documents")
ACCOUNTS_FILE = os.path.join(DOCUMENTS_PATH, "accounts.txt")
LOOP_DELAY = 10

# ========== DISCORD WEBHOOK ==========
def send_to_discord(email, status="success", error_msg=None):
    if status == "success":
        message = f"{email}"
    else:
        message = f"❌ {email} - {error_msg}"
    
    try:
        data = {"content": message}
        requests.post(DISCORD_WEBHOOK_URL, json=data, verify=False, timeout=10)
        return True
    except:
        return False

def save_account(email, password):
    try:
        os.makedirs(DOCUMENTS_PATH, exist_ok=True)
        with open(ACCOUNTS_FILE, "a", encoding='utf-8') as f:
            f.write(f"{email}:{password}\n")
        return True
    except:
        return False

class AutoRegisterGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("🤖 Auto Register Tool - Chạy Liên Tục")
        self.root.geometry("650x680")
        self.root.resizable(False, False)
        self.root.configure(bg='#1a1a2e')
        self.root.attributes('-topmost', True)
        
        self.root.protocol("WM_DELETE_WINDOW", self.on_closing)
        
        self.driver = None
        self.is_running = False
        self.is_looping = False
        self.current_email = None
        self.current_token = None
        self.success_count = 0
        self.fail_count = 0
        self.total_count = 0
        
        self.setup_ui()
        
    def on_closing(self):
        self.is_running = False
        self.is_looping = False
        if self.driver:
            try:
                self.driver.quit()
            except:
                pass
        self.root.destroy()
        
    def setup_ui(self):
        # Header
        header = tk.Frame(self.root, bg='#16213e', height=50)
        header.pack(fill='x')
        header.pack_propagate(False)
        tk.Label(header, text="🤖 AUTO REGISTER - LOOP MODE", font=('Segoe UI', 14, 'bold'), 
                 bg='#16213e', fg='white').pack(pady=12)
        
        # Main
        main = tk.Frame(self.root, bg='#1a1a2e', padx=15, pady=10)
        main.pack(fill='both', expand=True)
        
        # URL
        url_frame = tk.LabelFrame(main, text="🌐 URL", bg='#1a1a2e', fg='white', 
                                   font=('Segoe UI', 10, 'bold'), padx=8, pady=5)
        url_frame.pack(fill='x', pady=(0, 10))
        self.url_entry = tk.Entry(url_frame, font=('Segoe UI', 10), bg='#0f0f1a', fg='white',
                                   insertbackground='white', relief='flat')
        self.url_entry.pack(fill='x', pady=5)
        self.url_entry.insert(0, "https://ai-undress.ai/vi/auth/signup")
        
        # Stats
        stats_frame = tk.LabelFrame(main, text="📊 Thống kê", bg='#1a1a2e', fg='#4facfe',
                                     font=('Segoe UI', 10, 'bold'), padx=8, pady=5)
        stats_frame.pack(fill='x', pady=(0, 10))
        
        stats_inner = tk.Frame(stats_frame, bg='#1a1a2e')
        stats_inner.pack(fill='x')
        
        self.success_label = tk.Label(stats_inner, text="✅ Thành công: 0", font=('Segoe UI', 10),
                                       bg='#1a1a2e', fg='#43e97b')
        self.success_label.pack(side='left', padx=5)
        
        self.fail_label = tk.Label(stats_inner, text="❌ Thất bại: 0", font=('Segoe UI', 10),
                                    bg='#1a1a2e', fg='#f5576c')
        self.fail_label.pack(side='left', padx=5)
        
        self.total_label = tk.Label(stats_inner, text="📊 Tổng: 0", font=('Segoe UI', 10),
                                     bg='#1a1a2e', fg='#f9ca24')
        self.total_label.pack(side='left', padx=5)
        
        # Email
        email_frame = tk.LabelFrame(main, text="📧 Email hiện tại", bg='#1a1a2e', fg='white',
                                     font=('Segoe UI', 10, 'bold'), padx=8, pady=5)
        email_frame.pack(fill='x', pady=(0, 10))
        self.email_label = tk.Label(email_frame, text="Chưa tạo", font=('Consolas', 10), 
                                     bg='#0f0f1a', fg='#4facfe', anchor='w', padx=5, pady=3)
        self.email_label.pack(fill='x')
        
        # Status
        status_frame = tk.LabelFrame(main, text="📊 Trạng thái", bg='#1a1a2e', fg='#43e97b',
                                      font=('Segoe UI', 10, 'bold'), padx=8, pady=5)
        status_frame.pack(fill='x', pady=(0, 10))
        self.status_label = tk.Label(status_frame, text="🟢 Sẵn sàng", font=('Segoe UI', 10),
                                      bg='#1a1a2e', fg='#aaa')
        self.status_label.pack(anchor='w')
        
        # Buttons
        btn_frame = tk.Frame(main, bg='#1a1a2e')
        btn_frame.pack(fill='x', pady=(0, 10))
        
        self.loop_btn = tk.Button(btn_frame, text="🔄 CHẠY LIÊN TỤC", font=('Segoe UI', 11, 'bold'),
                                   bg='#4facfe', fg='white', padx=15, pady=8, relief='flat',
                                   cursor='hand2', command=self.start_loop)
        self.loop_btn.pack(side='left', expand=True, fill='x', padx=(0, 5))
        
        self.stop_btn = tk.Button(btn_frame, text="⏹️ DỪNG", font=('Segoe UI', 11, 'bold'),
                                  bg='#2d2d3f', fg='white', padx=15, pady=8, relief='flat',
                                  cursor='hand2', command=self.stop_loop, state='disabled')
        self.stop_btn.pack(side='right', expand=True, fill='x', padx=(5, 0))
        
        self.single_btn = tk.Button(main, text="▶️ CHẠY 1 LẦN", font=('Segoe UI', 10),
                                     bg='#2d2d3f', fg='white', padx=10, pady=5, relief='flat',
                                     cursor='hand2', command=self.start_automation)
        self.single_btn.pack(fill='x', pady=(0, 10))
        
        # Progress
        self.progress = ttk.Progressbar(main, mode='indeterminate', length=400)
        self.progress.pack(fill='x', pady=(0, 10))
        
        # Log
        log_frame = tk.LabelFrame(main, text="📋 LOG", bg='#1a1a2e', fg='#f9ca24',
                                   font=('Segoe UI', 10, 'bold'), padx=8, pady=5)
        log_frame.pack(fill='both', expand=True)
        
        self.log_text = scrolledtext.ScrolledText(log_frame, height=14, bg='#0a0a12', fg='#ccc',
                                                   font=('Consolas', 9), wrap=tk.WORD)
        self.log_text.pack(fill='both', expand=True)
        
        # Footer
        footer = tk.Frame(self.root, bg='#16213e', height=25)
        footer.pack(fill='x')
        tk.Label(footer, text=f"⏳ Chạy liên tục | Nghỉ {LOOP_DELAY}s | CHỜ LINK RỒI MỚI ĐÓNG TRÌNH DUYỆT", 
                 bg='#16213e', fg='#f9ca24', font=('Segoe UI', 8)).pack(pady=3)
    
    def update_stats(self):
        self.success_label.config(text=f"✅ Thành công: {self.success_count}")
        self.fail_label.config(text=f"❌ Thất bại: {self.fail_count}")
        self.total_label.config(text=f"📊 Tổng: {self.total_count}")
    
    def add_log(self, message, msg_type='info'):
        timestamp = time.strftime('%H:%M:%S')
        colors = {'info': '#ccc', 'success': '#43e97b', 'error': '#f5576c', 'warning': '#f9ca24', 'loop': '#4facfe'}
        color = colors.get(msg_type, '#ccc')
        self.log_text.insert(tk.END, f"[{timestamp}] {message}\n", f'c{msg_type}')
        self.log_text.tag_config(f'c{msg_type}', foreground=color)
        self.log_text.see(tk.END)
        self.root.update_idletasks()
    
    def update_status(self, text, is_running=False):
        self.status_label.config(text=text)
        self.status_label.config(fg='#4facfe' if is_running else '#aaa')
    
    def click_cloudflare_turnstile(self, driver):
        try:
            time.sleep(2)
            turnstile_frames = driver.find_elements(By.CSS_SELECTOR, 'iframe[src*="turnstile"]')
            
            if turnstile_frames:
                self.add_log("🛡️ Click Cloudflare Turnstile...", 'warning')
                for frame in turnstile_frames:
                    try:
                        driver.switch_to.frame(frame)
                        checkbox = WebDriverWait(driver, 5).until(
                            EC.element_to_be_clickable((By.CSS_SELECTOR, 'input[type="checkbox"]'))
                        )
                        checkbox.click()
                        self.add_log("✅ Đã click Turnstile", 'success')
                        driver.switch_to.default_content()
                        time.sleep(3)
                        return True
                    except:
                        driver.switch_to.default_content()
            return True
        except:
            return True
    
    def wait_for_submit_button_enabled(self, driver, timeout=40):
        self.add_log("⏳ Chờ nút 'Tạo tài khoản' sáng...", 'warning')
        start_time = time.time()
        
        while time.time() - start_time < timeout:
            try:
                buttons = driver.find_elements(By.XPATH, "//button[contains(text(), 'Tạo tài khoản') or contains(text(), 'Đăng ký')]")
                for btn in buttons:
                    if not btn.get_attribute('disabled'):
                        elapsed = int(time.time() - start_time)
                        self.add_log(f"✅ Nút đã sáng! (chờ {elapsed}s)", 'success')
                        return btn
                
                submit_btns = driver.find_elements(By.CSS_SELECTOR, 'button[type="submit"]')
                for btn in submit_btns:
                    if not btn.get_attribute('disabled'):
                        elapsed = int(time.time() - start_time)
                        self.add_log(f"✅ Nút submit đã sẵn sàng! (chờ {elapsed}s)", 'success')
                        return btn
                
                time.sleep(0.5)
            except:
                time.sleep(0.5)
        
        self.add_log("⚠️ Hết thời gian chờ", 'error')
        return None
    
    def create_temp_email(self):
        try:
            response = requests.get("https://api.mail.tm/domains", timeout=30)
            domain = response.json()['hydra:member'][0]['domain']
            local_part = str(uuid.uuid4())[:8]
            self.current_email = f"{local_part}@{domain}"
            
            requests.post("https://api.mail.tm/accounts", json={
                "address": self.current_email, "password": self.current_email
            }, timeout=30)
            
            resp = requests.post("https://api.mail.tm/token", json={
                "address": self.current_email, "password": self.current_email
            }, timeout=30)
            self.current_token = resp.json()['token']
            
            self.email_label.config(text=self.current_email)
            self.add_log(f"📧 Email: {self.current_email}", 'success')
            return True
        except Exception as e:
            self.add_log(f"❌ Lỗi tạo email: {e}", 'error')
            return False
    
    def fill_register_form(self):
        try:
            wait = WebDriverWait(self.driver, 10)
            
            email_input = wait.until(EC.presence_of_element_located(
                (By.CSS_SELECTOR, 'input[type="email"], input[name="email"]')
            ))
            email_input.clear()
            for char in self.current_email:
                email_input.send_keys(char)
                time.sleep(0.03)
            email_input.send_keys('\n')
            self.add_log("📧 Đã nhập email + Enter", 'success')
            time.sleep(2)
            
            self.click_cloudflare_turnstile(self.driver)
            time.sleep(2)
            
            pwd_input = self.driver.find_element(By.CSS_SELECTOR, 'input[type="password"]')
            pwd_input.clear()
            for char in self.current_email:
                pwd_input.send_keys(char)
                time.sleep(0.03)
            self.add_log("🔑 Đã nhập mật khẩu", 'success')
            time.sleep(1)
            
            submit_btn = self.wait_for_submit_button_enabled(self.driver, timeout=40)
            
            if submit_btn:
                submit_btn.click()
                self.add_log("✅ Đã click Tạo tài khoản", 'success')
                return True
            return False
        except Exception as e:
            self.add_log(f"❌ Lỗi: {e}", 'error')
            return False
    
    def wait_for_confirmation_and_close(self, driver, email, token):
        """
        CHỜ EMAIL XÁC NHẬN, CLICK LINK, SAU ĐÓ MỚI ĐÓNG TRÌNH DUYỆT
        """
        self.add_log("📧 Đang chờ email xác nhận...", 'info')
        start_time = time.time()
        timeout = 90
        last_checked = set()
        
        while time.time() - start_time < timeout:
            try:
                if not token:
                    time.sleep(2)
                    continue
                
                headers = {"Authorization": f"Bearer {token}"}
                resp = requests.get("https://api.mail.tm/messages", headers=headers, timeout=30)
                messages = resp.json().get('hydra:member', [])
                
                if messages:
                    for msg in messages:
                        if msg['id'] in last_checked:
                            continue
                        last_checked.add(msg['id'])
                        
                        detail = requests.get(f"https://api.mail.tm/messages/{msg['id']}", 
                                              headers=headers, timeout=30).json()
                        html = detail.get('html', [''])[0] or detail.get('text', [''])[0]
                        
                        links = re.findall(r'https?://[^\s"\'<>\[\]{}|\\^`\n\r]+', html)
                        for link in links:
                            if any(kw in link.lower() for kw in ['confirm', 'verify', 'activate']):
                                self.add_log(f"🔗 TÌM THẤY LINK XÁC NHẬN!", 'success')
                                self.add_log(f"🔗 Đang mở link: {link[:80]}...", 'link')
                                
                                # Mở link xác nhận trong tab mới
                                driver.execute_script(f"window.open('{link}', '_blank');")
                                self.add_log("✅ Đã mở link xác nhận", 'success')
                                
                                # Lưu tài khoản
                                if save_account(email, email):
                                    self.add_log(f"💾 Đã lưu: {email}", 'success')
                                
                                # Gửi Discord
                                send_to_discord(email, "success")
                                self.add_log(f"📨 Đã gửi Discord: {email}", 'success')
                                
                                # Chờ 3 giây để link load
                                time.sleep(3)
                                
                                self.add_log("🎉 HOÀN TẤT! Đóng trình duyệt...", 'success')
                                return True
                
                remaining = int(timeout - (time.time() - start_time))
                if remaining > 0:
                    self.add_log(f"⏳ Chờ email... còn {remaining}s", 'info')
                time.sleep(5)
                
            except Exception as e:
                self.add_log(f"⚠️ Lỗi kiểm tra: {e}", 'warning')
                time.sleep(5)
        
        self.add_log("❌ Hết thời gian chờ, không nhận được link xác nhận", 'error')
        send_to_discord(email, "error", "Timeout - Không nhận link")
        return False
    
    def click_age_button(self):
        try:
            age_btn = WebDriverWait(self.driver, 5).until(
                EC.element_to_be_clickable((By.XPATH, "//button[contains(text(), 'Tôi từ 18')]"))
            )
            age_btn.click()
            self.add_log("✅ Đã click nút 18+", 'success')
            time.sleep(1)
        except:
            pass
    
    def run_one_account(self):
        """Tạo 1 tài khoản, chờ link xong mới đóng trình duyệt"""
        driver = None
        try:
            self.add_log("🚀 Khởi tạo Chrome...", 'info')
            options = webdriver.ChromeOptions()
            options.add_argument('--start-maximized')
            options.add_argument('--ignore-certificate-errors')
            options.add_argument('--disable-blink-features=AutomationControlled')
            options.add_experimental_option('excludeSwitches', ['enable-automation'])
            driver = webdriver.Chrome(options=options)
            self.driver = driver
            self.add_log("✅ Chrome sẵn sàng", 'success')
            
            # Mở trang
            driver.get(self.url_entry.get())
            self.add_log(f"🌐 Đã mở trang", 'info')
            time.sleep(3)
            
            # Click 18+
            self.click_age_button()
            
            # Tạo email
            if not self.create_temp_email():
                raise Exception("Tạo email thất bại")
            
            # Điền form và click tạo tài khoản
            if not self.fill_register_form():
                raise Exception("Điền form thất bại")
            
            # QUAN TRỌNG: CHỜ LINK XÁC NHẬN VÀ CLICK, SAU ĐÓ MỚI ĐÓNG
            success = self.wait_for_confirmation_and_close(driver, self.current_email, self.current_token)
            
            return success
            
        except Exception as e:
            self.add_log(f"❌ Lỗi: {e}", 'error')
            return False
        finally:
            # Đóng trình duyệt sau khi đã xử lý xong
            if driver:
                try:
                    driver.quit()
                    self.add_log("🚪 Đã đóng trình duyệt", 'info')
                except:
                    pass
            self.driver = None
    
    def start_loop(self):
        if self.is_looping:
            return
        
        self.is_looping = True
        self.is_running = True
        self.success_count = 0
        self.fail_count = 0
        self.total_count = 0
        self.update_stats()
        
        self.loop_btn.config(state='disabled')
        self.single_btn.config(state='disabled')
        self.stop_btn.config(state='normal')
        self.progress.start(10)
        self.update_status("🔄 Đang chạy vòng lặp...", True)
        
        def loop_worker():
            while self.is_looping:
                self.total_count += 1
                self.add_log(f"\n{'='*50}", 'loop')
                self.add_log(f"🔄 LẦN {self.total_count} - {datetime.now().strftime('%H:%M:%S')}", 'loop')
                self.add_log(f"{'='*50}", 'loop')
                
                success = self.run_one_account()
                
                if success:
                    self.success_count += 1
                    self.add_log(f"✅ Lần {self.total_count} THÀNH CÔNG", 'success')
                else:
                    self.fail_count += 1
                    self.add_log(f"❌ Lần {self.total_count} THẤT BẠI", 'error')
                
                self.update_stats()
                self.add_log(f"📊 Thống kê: ✅{self.success_count} ❌{self.fail_count} 📊{self.total_count}", 'info')
                
                if self.is_looping:
                    self.add_log(f"⏳ Nghỉ {LOOP_DELAY}s trước lần tiếp theo...", 'warning')
                    for i in range(LOOP_DELAY, 0, -1):
                        if not self.is_looping:
                            break
                        self.add_log(f"   ⏱️ Chờ {i}s...", 'info')
                        time.sleep(1)
            
            self.root.after(0, self.stop_loop)
        
        threading.Thread(target=loop_worker, daemon=True).start()
    
    def stop_loop(self):
        self.is_looping = False
        self.is_running = False
        if self.driver:
            try:
                self.driver.quit()
            except:
                pass
            self.driver = None
        
        self.loop_btn.config(state='normal')
        self.single_btn.config(state='normal')
        self.stop_btn.config(state='disabled')
        self.progress.stop()
        self.update_status("🟢 Đã dừng")
        self.add_log(f"⏹️ ĐÃ DỪNG - Thống kê cuối: ✅{self.success_count} ❌{self.fail_count} 📊{self.total_count}", 'success')
    
    def start_automation(self):
        if self.is_running:
            return
        self.is_running = True
        self.single_btn.config(state='disabled')
        self.stop_btn.config(state='normal')
        self.progress.start(10)
        self.update_status("🔄 Đang chạy 1 lần...", True)
        self.add_log("▶️ CHẠY 1 LẦN", 'success')
        
        def worker():
            self.total_count += 1
            success = self.run_one_account()
            if success:
                self.success_count += 1
            else:
                self.fail_count += 1
            self.update_stats()
            self.is_running = False
            self.root.after(0, self.stop_automation)
        
        threading.Thread(target=worker, daemon=True).start()
    
    def stop_automation(self):
        self.is_running = False
        self.progress.stop()
        if self.driver:
            try:
                self.driver.quit()
            except:
                pass
            self.driver = None
        self.single_btn.config(state='normal')
        self.stop_btn.config(state='disabled')
        self.update_status("🟢 Đã dừng")
        self.add_log("⏹️ Đã dừng", 'info')

if __name__ == "__main__":
    try:
        root = tk.Tk()
        app = AutoRegisterGUI(root)
        root.mainloop()
    except KeyboardInterrupt:
        print("\n🛑 Đã dừng")
        sys.exit(0)